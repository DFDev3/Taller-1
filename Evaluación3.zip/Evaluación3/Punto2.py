import numpy as np 
A = np.array([[1,0,-1], 
              [2,0,2], 
              [8,2,-3]]) 
print(np.linalg.inv(A))