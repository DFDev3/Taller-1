def REGRESION(x=list,y=list):
        coefficients = np.polyfit(x,y,1)
        print(f"\n\nLa ecuación de la recta de la regresión lineal es y = {coefficients[0]}x + ({coefficients[1]})\n\n")
        return coefficients
from math import sqrt, log
import os
import numpy as np
isActive=True
headers=["MODELO EXPONENCIAL","ECUACIONES DE POTENCIA","RAZONES DE CRECIMIENTO","SALIR"]
while isActive:
    x = np.array([1,2,3.0,4,5,6,7,8])
    y = np.array([7.5,8,8.5,9.2,9.9,10.5,11.5,12.2])
    os.system('pause')
    # os.system('cls')
    print("\n\n             REGRESIONES\n\n\n")
    for i in range(len(headers)):
        print(f"{i+1} - {headers[i]}")
    op=int(input("_"))
    os.system('cls')
    if op==1:
        log_y = np.log(y)
        REGRESION(x,log_y)
    elif op==2:
        log_x = np.log10(x)
        log_y = np.log10(y)
        REGRESION(log_x,log_y)
    elif op==3:
        for i in range(len(x)):
            x[i]=float(1/x[i])
            y[i]=float(1/y[i])
        print(x)
        print(y)
        REGRESION(x,y)
    elif op==4:
        isActive=False