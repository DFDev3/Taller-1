# ###### DEFINICIÓN DE CONJUNTOS ###### #

def CrearA():
    A=set()
    i=5
    while i<20:
        i+=1
        A.add(i)
    return A
def CrearB():
    B=set()
    i=0
    while i<24:
        i+=2
        B.add(i)
    return B
def CrearC():
    C={1,4,8,10,12,15,18,20}
    return C
def CrearD():
    D={2,3,5,7,11,13,17,23,29,31,37,41,43}
    return D

# ###### DEFINICIÓN DE OPERACIONES ###### #

def UNION(A=set,B=set):
    E=set()
    for i in A:
        E.add(i)
    for i in B:
        E.add(i)
    return E
def INTERSECCION(A=set,B=set):
    F=A&B
    return F
def DIFERENCIA(A=set,B=set):
    G=A-B
    return G
def DIFSIME(A=set,B=set):
    H=A^B
    return H



