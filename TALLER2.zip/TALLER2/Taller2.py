# Cree un programa, basado en el programa creado en el taller 1, en el que cada operación sea una función, de acuerdo con las indicaciones dadas por el docente.

# Utilizando el programa ajustado y partiendo de los sieguientes conjuntos.

# A={x | x e Z y x>5 y x<=20}
# B={x | x e N y x<25 y múltiplo de 2}
# C={1,4,8,10,12,15,18,20}
# D={x | x e N y x <=45 y x es primo}

# Resuelva las siguientes operaciones
#     B interseccion (C dif. simétrica D)
#     B union ( A interseccion C)
#     (B union D) diferencia C
#     (A diferencia B) dif. simétrica (A intersenccion D)

from defs import *
import os
import time

A=CrearA()
B=CrearB()
C=CrearC()
D=CrearD()

print(" OPERACIONES ")
print("B INTERSECCION (C DIF. SIMÉTRICA D)")
print("B UNION ( A INTERSECCION C")
print("(B union D) diferencia C")
print("(A DIFERENCIA B) DIF. SIMÉTRICA (A INTERSECCION D)")
print("___________________________________________")
print(INTERSECCION(B,DIFSIME(C,D)))
print(UNION(B,INTERSECCION(A,C)))
print(DIFERENCIA(C,UNION(B,D)))
print(DIFSIME(DIFERENCIA(A,B),INTERSECCION(A,D)))